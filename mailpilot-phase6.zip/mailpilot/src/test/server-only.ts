// Vitest stand-in for the "server-only" package (which throws outside Next's server bundle).
export {};
